#include <iostream>
using namespace std;


int main()
{
    int** array;
    int row, col, i, j;
 int m1[10][10], m2[10][10], m3[10][10], prod[10][10];

    
    cout << "Enter the number of rows" << endl;
    cin >> row;
    cout << "Enter the number of columns" << endl;
    cin >> col;
 
    //Dynamically allocating row space in heap
    array = new int*[row];
    //Dynamically allocating column space in heap
    for(i=0; i<row; i++){
        array[i] = new int[col];
    }
 
    //Taking input in the array
    cout<<"first array ";
    cout << "Enter "<< (row * col) <<" numbers \n";
    for(i=0; i<row; i++){
        for(j=0; j<col; j++){
            cout << "Enter element at "<< i+1 << " row " << j+1 << " column"<< endl;
            cin >> m1[i][j];
        }
    }
    cout<<"second array ";
 cout << "Enter "<< (row * col) <<" numbers \n";
    for(i=0; i<row; i++){
        for(j=0; j<col; j++){
            cout << "Enter element at "<< i+1 << " row " << j+1 << " column"<< endl;
            cin >> m2[i][j];
        }
    }
 
    //Displaying array
    cout << "Matrix first is: \n";

  for(i=0; i<row; i++){
        for(j=0; j<col; j++){
        cout<<m1[i][j]<<endl;
        }
        printf(" \n ");
        }

      cout << "Matrix second is: \n";
  for(i=0; i<row; i++){
        for(j=0; j<col; j++){
        cout<<m2[i][j];
        }
        printf(" \n ");
        }

        //sum of both matrixint i,j;
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            *(*(m3 + i) + j) =(*(*(m1 + i) + j))+(*(*(m2 + i) + j));}
    }

    cout<<"sum of both matrix ";
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
          cout<<m3[i][j];
      
        }
      printf(" \n ");  
    }

    //product of both matrix
 for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++) {
         int sum = 0;
         for (i = 0; i < col; i++) {
            sum += (*(*(m1 + row) + i)) * (*(*(m2 + j) + col));
         }
         *(*(prod + row) + col) = sum;
      }
   }     

         cout<<"product of both matrix ";
         for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++) {
         cout<< *(*(prod + row) + col);
      }
      printf(" \n ");
   }

    //Free space after the use of array
    delete [] array;
}